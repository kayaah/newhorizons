using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScreenBoundaries : MonoBehaviour
{
    //This script makes it so that when you collide with one of the sides of the screen, you end up on the other side.
    public bool revertX = false; //If the wall is vertical, this should be checked
    public bool revertY = false; //If the wall is horizontal, this should be checked
    
    private void OnTriggerEnter2D(Collider2D other) { //On colliding with something (as a trigger)
        if(other.gameObject.tag != "Bullet"){ //If the collided object is anything other than a bullet
        if(revertX)
        {   //Revert the object X position, while slightly reducing it so the object does not
            //overlap with the other boundary on the other side.
            other.transform.position = new Vector2(-other.transform.position.x * 0.95f, other.transform.position.y);
        }
        if(revertY)
        {   //Revert the object Y position, while slightly reducing it so the object does not
            //overlap with the other boundary on the other side.
            other.transform.position = new Vector2(other.transform.position.x, -other.transform.position.y * 0.95f);
        }
        }
    }
}
