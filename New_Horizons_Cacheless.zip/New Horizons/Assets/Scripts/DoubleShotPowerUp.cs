using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DoubleShotPowerUp : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D other) { //On colliding with something (as a trigger)
        if(other.gameObject.tag == "Player"){ //If it's a player
            //Find the player combat script and call the powerup coroutine
            FindObjectOfType<PlayerCombat>().StartCoroutine("DoubleShotPowerUp"); 
            Destroy(gameObject); //Destroy me
        }
    }
}
