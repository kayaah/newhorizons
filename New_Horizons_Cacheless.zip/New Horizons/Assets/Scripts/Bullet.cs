using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{

    private void OnTriggerEnter2D(Collider2D other) { //On colliding with something (as a trigger)
        if(other.gameObject.tag == "Asteroid") //If it's an asteroid
        {
            other.gameObject.GetComponent<Asteroid>().Damage(1); //Get it's Asteroid script and damage it
        }
        else if(other.gameObject.tag == "EnemyShip") //If it's an Enemy Ship
        {
            other.gameObject.GetComponent<EnemyShip>().Damage(1); //Get it's EnemyShip script and damage it
        }
        Destroy(gameObject);//Destroy me
    }
    
}
