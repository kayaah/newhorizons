using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    private Rigidbody2D rb; //Rigidbody
    public float acceleration = 1;
    public float rotationSpeed = 1;
    void Start()
    {
        rb = GetComponent<Rigidbody2D>(); //Get rigidbody
    }


    void FixedUpdate()
    {
        //Get Input axis values
        Vector2 input = new Vector2(Input.GetAxisRaw("Horizontal"),Input.GetAxisRaw("Vertical"));
        if(input.y > 0) //If pressed Up
        {
            rb.AddForce(transform.up * acceleration);
        }
        else if(input.y < 0) //If pressed Down
        {
            rb.AddForce(transform.up * -acceleration);
        }

        if(input.x > 0) //If pressed Right
        {
            transform.Rotate(0,0,-rotationSpeed);
        }
        else if(input.x < 0) //If pressed Left
        {
            transform.Rotate(0,0,rotationSpeed);
        }
    }
}
