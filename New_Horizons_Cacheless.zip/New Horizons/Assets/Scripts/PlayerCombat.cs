using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerCombat : MonoBehaviour
{
    public GameObject bulletPrefab; //Player bullet prefab
    public float bulletSpeed = 500; //Bullet speed
    public bool doubleShot = false; //Double shot powerup toggle
    public int doubleShotDuration = 15; //Double shot powerup duration
    public bool canShoot = true;
    
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.Z) && canShoot) //If Z key is pressed & allowed to shoot
        {
            StartCoroutine("Shoot"); //Shoot
        }   
    }

    IEnumerator Shoot(){
        GameObject bullet = Instantiate(bulletPrefab, transform.position, transform.localRotation); //Spawn bullet
        bullet.GetComponent<Rigidbody2D>().AddForce(transform.up * bulletSpeed); //Add force to it
        Destroy(bullet, 3); //Destroy it in 3 seconds if it doesn't hit anything

        yield return new WaitForSeconds(0.1f);//Wait 0.1 seconds

        if(doubleShot){ //If double shot is enabled, repeat the process
            GameObject bullet2 = Instantiate(bulletPrefab, transform.position, transform.localRotation);
            bullet2.GetComponent<Rigidbody2D>().AddForce(transform.up * bulletSpeed);
            Destroy(bullet2, 3);
        }
    }

    public IEnumerator DoubleShotPowerUp(){
        doubleShot = true;
        yield return new WaitForSeconds(doubleShotDuration);
        doubleShot = false;
    }
}
