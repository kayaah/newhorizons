using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KillAllPowerUp : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D other) { //On colliding with something (as a trigger)
        if(other.gameObject.tag == "Player"){ //If it's a player
            //Find all asteroids and kill them
            foreach(Asteroid item in FindObjectsOfType<Asteroid>()) 
            {
                item.Die();
            }
            //Find all enemy ships and kill them
            foreach(EnemyShip item in FindObjectsOfType<EnemyShip>())
            {
                item.Die();
            }
            Destroy(gameObject);
        }
    }
}
