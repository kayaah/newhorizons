using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBullet : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D other) { //On colliding with something (as a trigger)
        if(other.gameObject.tag == "Player") //If it's a player
        {
            other.gameObject.GetComponent<PlayerLives>().Die(); //Kill the player
        }
        Destroy(gameObject); //Destroy me
    }
}
