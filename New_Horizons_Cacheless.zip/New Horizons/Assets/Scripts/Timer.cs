using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Timer : MonoBehaviour
{
    public float startTime; //Starting time
    private float timer;
    public TextMeshProUGUI textObject; //UI timer text object
    public GameObject stageCompleteScreen; //Stage complete UI screen

    void Start()
    {
        timer = startTime; //Set the timer to the starting vlaue
    }

    // Update is called once per frame
    void Update()
    {
        timer -= Time.deltaTime; //This makes the timer work
        if(timer >= 0) //If timer is active (more than 0), update the UI
        textObject.text = Mathf.Floor(timer).ToString();
        if(timer < 0) //If not, end the game
        {
            EndGame();
        }
    }

    private void EndGame(){
        //End the game
        Time.timeScale = 0; //Freeze time
        stageCompleteScreen.SetActive(true); //Enable stage complete UI
    }
}
