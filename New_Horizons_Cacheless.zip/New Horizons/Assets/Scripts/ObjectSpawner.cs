using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectSpawner : MonoBehaviour
{
    public float spawnableX;
    public float spawnableY;

    public GameObject[] objectsToSpawn; //Objects to spawn every cycle

    void Start()
    {
        StartCoroutine("CheckIfNoObjectsLeft");
    }

    void SpawnObjects(){
        foreach(GameObject obj in objectsToSpawn) //For each object to spawn:
        {
            Vector2 position = Vector2.zero;
            int random = Random.Range(1,5); //Randomly choose a number from 1,2,3,4
            if(random == 1) //if 1; choose a point on the top line
            {
                position = new Vector2(Random.Range(-spawnableX,spawnableX), spawnableY);
            }
            else if(random == 2) //if 2; choose a point on the bottom line
            {
                position = new Vector2(Random.Range(-spawnableX,spawnableX), -spawnableY);
            }
            else if(random == 3) //if 3; choose a point on the right line
            {
                position = new Vector2(spawnableX, Random.Range(-spawnableY,spawnableY));
            }
            else if(random == 4) //if 4; choose a point on the left line
            {
                position = new Vector2(-spawnableX, Random.Range(-spawnableY,spawnableY));
            }
            Instantiate(obj,position,Quaternion.identity); //Spawn the object at that position
        }
    }

    IEnumerator CheckIfNoObjectsLeft(){
        while(true){ //Always:
            if(GameObject.FindGameObjectsWithTag("Asteroid").Length == 0 //If no game objects exist with Asteroid tag
            && GameObject.FindGameObjectsWithTag("EnemyShip").Length == 0) //If no game objects exist with EnemyShip tag
            {
                yield return new WaitForSeconds(1); //Wait 1 seconds
                SpawnObjects(); //Then spawn the objects
            }
            //Wait 2 seconds before continuing the loop
            yield return new WaitForSeconds(2);
        }
    }

    //Visualize the spawnable points on the editor, when this object is selected.
    private void OnDrawGizmosSelected() { 
        Gizmos.DrawRay(new Vector2(-spawnableX, spawnableY) ,Vector2.right * spawnableX * 2);
        Gizmos.DrawRay(new Vector2(-spawnableX, -spawnableY) ,Vector2.right * spawnableX * 2);
        Gizmos.DrawRay(new Vector2(spawnableX, -spawnableY) ,Vector2.up * spawnableY * 2);
        Gizmos.DrawRay(new Vector2(-spawnableX, -spawnableY) ,Vector2.up * spawnableY * 2);
    }
}
