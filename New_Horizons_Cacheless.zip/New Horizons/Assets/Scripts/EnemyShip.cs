using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyShip : MonoBehaviour
{
    public int maxHealth = 3; //Starting health
    private int health; //Current health
    private Rigidbody2D rb; //Rigidbody
    public int scoreToGive = 100; //Amount of score to give on death
    private float randomRotation; //Current amount to rotate
    public float randomRotationMultiplier = 1;
    public float randomSpeedMultiplier = 1;
    public float shootInterval = 1.5f; //Shoot every x seconds
    public GameObject bulletPrefab; //Bullet prefab reference
    public float bulletSpeed = 3; //Bullet's speed
    void Start()
    {
        health = maxHealth; //Set health to start value
        rb = GetComponent<Rigidbody2D>(); //Get rigidbody
        //Set the random rotation amount to a random value depending on the random rotation multiplier
        randomRotation = Random.Range(-1f * randomRotationMultiplier,1f * randomRotationMultiplier);
        //Give random amounts of force for natural space-esque movement
        rb.AddForce(transform.right * Random.Range(-100f,100f) * randomSpeedMultiplier);
        rb.AddForce(transform.up * Random.Range(-100f,100f) * randomSpeedMultiplier);
        //Start the shoot coroutine
        StartCoroutine("Shoot");
    }

    
    void FixedUpdate()
    {
        transform.Rotate(0,0,randomRotation); //Constantly rotate
    }


    IEnumerator Shoot(){
        while(true) //Always:
        {
            yield return new WaitForSeconds(shootInterval); //Wait for x seconds
            GameObject bullet = Instantiate(bulletPrefab, transform.position, transform.localRotation); //Spawn the bullet
            bullet.GetComponent<Rigidbody2D>().AddForce(transform.up * bulletSpeed); //Set it's speed
            Destroy(bullet, 3); //Destroy the bullet in 3 seconds if it doesn't hit anything
        }
    }


    public void Damage(int value){
        health -= value; //Reduce health by value
        if(health <= 0) //If it's below 0, die
        {
            Die();
        }
    }

    public void Die(){
        FindObjectOfType<Score>().AddScore(scoreToGive); //Find the score script and add the score to it
        Destroy(gameObject); //Destroy me
    }

    private void OnCollisionEnter2D(Collision2D other) { //On colliding with something
        if(other.gameObject.tag == "Player") //If it's a player
        {
            other.gameObject.GetComponent<PlayerLives>().Die(); //Kill player
            Destroy(gameObject); //Destroy me
        }
    }
}
