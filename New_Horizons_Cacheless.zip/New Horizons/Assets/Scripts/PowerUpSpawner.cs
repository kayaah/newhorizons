using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class PowerUpSpawner : MonoBehaviour
{
    public float spawnableX;
    public float spawnableY;
    public float randomTimerMin = 10; //Min value for timer
    public float randomTimerMax = 25; //Max value for timer
    private float timer;
    public GameObject[] powerUps; //Spawnable powerup prefabs
    private void Start() {
        timer = randomTimerMin;
    }

    private void Update() {
        timer -= Time.deltaTime; //This makes the timer work
        if(timer < 0) //If time is out
        {
            Spawn(); //Spawn PowerUp
            timer = Random.Range(randomTimerMin,randomTimerMax); //Reset timer to a random value
        }
    }

    void Spawn(){
        Instantiate(powerUps[Random.Range(0,powerUps.Length)], //Randomly choose powerup
        new Vector2(Random.Range(-spawnableX, spawnableX), Random.Range(-spawnableY, spawnableY)) //Randomly choose position
        , Quaternion.identity);
    }

    //Visualize the spawnable boundaries on the editor, when this object is selected.
    private void OnDrawGizmosSelected() {
        Gizmos.DrawRay(new Vector2(-spawnableX, spawnableY) ,Vector2.right * spawnableX * 2);
        Gizmos.DrawRay(new Vector2(-spawnableX, -spawnableY) ,Vector2.right * spawnableX * 2);
        Gizmos.DrawRay(new Vector2(spawnableX, -spawnableY) ,Vector2.up * spawnableY * 2);
        Gizmos.DrawRay(new Vector2(-spawnableX, -spawnableY) ,Vector2.up * spawnableY * 2);
    }
}
