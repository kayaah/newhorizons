using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class PlayerLives : MonoBehaviour
{
    public int maxLives = 3; //Starting lives
    private int lives; //Current lives
    public float respawnTime = 1;
    public float spawnInvincibilityTime = 1; //The time frame in which the player is invincible after respawn
    public TextMeshProUGUI text; //UI text to show lives
    public GameObject gameOverScreen; // If lives run out, show this screen
    private Rigidbody2D rb; //Rigidbody
    private BoxCollider2D coll; //Collider
    public SpriteRenderer spriteRenderer; //Sprite renderer (set this variable in the inspector)
    void Start()
    {
        rb = GetComponent<Rigidbody2D>(); //Get rigidbody
        coll = GetComponent<BoxCollider2D>(); //Get collider
        lives = maxLives; //Set current lives
        text.text = "Lives: " + lives; //Set UI text
    }

    public void Die(){
        lives -= 1; //Reduce lives by 1
        text.text = "Lives: " + lives; //Update UI text
        coll.enabled = false; //Disable collider
        spriteRenderer.enabled = false; //Disable sprite renderer
        GetComponent<PlayerCombat>().canShoot = false; //Disable player shooting
        if(lives <= 0)
        { //If no lives left
            GameOver();
        }
        else
        { //If life count is more than 0
            StartCoroutine("Respawn");
        }
    }

    IEnumerator Respawn(){
        yield return new WaitForSeconds(respawnTime); //Wait
        transform.position = Vector2.zero; //Reset position of the player
        rb.velocity = Vector2.zero; //Reset velocity of the player
        GetComponent<PlayerCombat>().canShoot = true; //Enable player shooting
        spriteRenderer.enabled = true; //Enable sprite renderer
        spriteRenderer.color = Color.gray; //Set sprite color to gray, to symbolize invincibility
        yield return new WaitForSeconds(spawnInvincibilityTime); //Wait
        coll.enabled = true; //Enable collider so that the player can get hit
        spriteRenderer.color = Color.white; //Set the color back to normal
    }

    public void GameOver(){
        gameOverScreen.SetActive(true); //Show the game over screen
        Time.timeScale = 0; //Freeze time
    }
}
