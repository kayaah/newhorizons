using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Score : MonoBehaviour
{
    public int score = 0;
    public TextMeshProUGUI textObject; //UI score display text
    public TextMeshProUGUI completeScreenTextObject; //UI score display text on the level complete screen
    
    public void AddScore(int value)
    {
        score += value; //Add to score
        textObject.text = score.ToString(); //Update UI
        completeScreenTextObject.text = "Score: " + score.ToString(); //Update level complete UI
    }
}
