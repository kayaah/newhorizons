using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
    public GameObject mainMenu; //Main menu parent
    public GameObject optionsMenu; //Options menu parent
    void Start()
    {
       mainMenu.SetActive(true);
       optionsMenu.SetActive(false); 
    }

    public void StartGame(){
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1); //Load next scene
    }

    void HideAll(){
        mainMenu.SetActive(false);
        optionsMenu.SetActive(false); 
    }

    public void ShowMainMenu(){
        HideAll();
        mainMenu.SetActive(true);
    }

    public void ShowOptionsMenu(){
        HideAll();
        optionsMenu.SetActive(true);
    }

    public void QuitGame(){
        Application.Quit();
    }
}
