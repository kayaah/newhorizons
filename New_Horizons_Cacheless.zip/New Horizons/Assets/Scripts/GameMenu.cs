using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameMenu : MonoBehaviour
{
    public void Start(){
        Time.timeScale = 1; //Set the game speed to normal
    }
    public void Restart(){
        Time.timeScale = 1; //Set the game speed to normal
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex); //Reload current scene
    }

    public void NextLevel(){
        Time.timeScale = 1; //Set the game speed to normal
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1); //Load next scene
    }

    public void BackToMainMenu(){
        Time.timeScale = 1; //Set the game speed to normal
        SceneManager.LoadScene(0); //Load starting scene
    }
}
