using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Asteroid : MonoBehaviour
{
    public int maxHealth = 3; //Starting health
    private int health; //Current health
    public GameObject[] objectsToSpawnOnDeath; //A list of objects to spawn when the asteroid gets destroyed (eg. smaller asteroids)
    private Rigidbody2D rb; //Rigidbody
    public int scoreToGive = 100; //Amount of score to give on death
    public void Start()
    {
        rb = GetComponent<Rigidbody2D>(); //Get my rigidbody
        health = maxHealth; //Set current health to max health
        transform.Rotate(0,0,Random.Range(-360,360)); //Rotate randomly
        rb.AddForce(transform.right * Random.Range(-50f,50f)); //Add a random amount of force for natural space-esque movement
        rb.AddForce(transform.up * Random.Range(-50f,50f));
    }
    
    public void Damage(int value){
        health -= value; //Reduce health by value
        if(health <= 0) //If it's below 0, die
        {
            Die();
        }
    }

    public void Die(){
        foreach(GameObject item in objectsToSpawnOnDeath) //For each object in our objects to spawn list,
        {
            GameObject asteroid = Instantiate(item,transform.position,Quaternion.identity); //Spawn the object.
        }
        FindObjectOfType<Score>().AddScore(scoreToGive); //Find the score script and add the score to it
        Destroy(gameObject); //Destroy me
    }

    private void OnCollisionEnter2D(Collision2D other) { //On colliding with something
        if(other.gameObject.tag == "Player") //If it's a player
        {
            other.gameObject.GetComponent<PlayerLives>().Die(); //Kill player
            Destroy(gameObject); //Destroy me
        }
    }
}
